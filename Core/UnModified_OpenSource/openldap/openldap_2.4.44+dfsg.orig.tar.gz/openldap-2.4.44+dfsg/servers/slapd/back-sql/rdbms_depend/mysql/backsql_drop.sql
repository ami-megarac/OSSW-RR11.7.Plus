DROP TABLE IF EXISTS ldap_entry_objclasses;

DROP TABLE IF EXISTS ldap_attr_mappings;

DROP TABLE IF EXISTS ldap_entries;

DROP TABLE IF EXISTS ldap_oc_mappings;
